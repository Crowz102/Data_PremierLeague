-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: datawarehouse
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dimreferee`
--

DROP TABLE IF EXISTS `dimreferee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dimreferee` (
  `RefereelD` int NOT NULL,
  `RefereeName` varchar(255) NOT NULL,
  PRIMARY KEY (`RefereelD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dimreferee`
--

LOCK TABLES `dimreferee` WRITE;
/*!40000 ALTER TABLE `dimreferee` DISABLE KEYS */;
INSERT INTO `dimreferee` VALUES (1,'Rob Harris'),(2,'Graham Barber'),(3,'Barry Knight'),(4,'Andy D\'Urso'),(5,'Dermot Gallagher'),(6,'Mike Riley'),(7,'Paul Durkin'),(8,'Steve Dunn'),(9,'Alan Wiley'),(10,'Steve Lodge'),(11,'Graham Poll'),(12,'Mark Halsey'),(13,'Jeff Winter'),(14,'Peter Jones'),(15,'Andy Hall'),(16,'David Ellaray'),(17,'F Taylor'),(18,'Rob Styles'),(19,'Steve Bennett'),(20,'Ian Harris'),(21,'Paul Taylor'),(22,'Neale Barry'),(23,'Mike Dean'),(24,'Roy Burton'),(25,'Matt Messias'),(26,'Clive Wilkes'),(27,'Andy D\'Urso '),(28,'Mark Halsey '),(29,'Steve Bennett '),(30,'N. S. Barry'),(31,'P. A. Durkin'),(32,'C. R. Wilkes '),(33,'R. Styles'),(34,'J. T. Winter'),(35,'G. P. Barber'),(36,'G. Poll'),(37,'D. J. Gallagher'),(38,'A. P. D\'Urso '),(39,'P. Jones '),(40,'D. R. Elleray '),(41,'J. T. Winter '),(42,'S. W. Dunn '),(43,'E. K. Wolstenholme '),(44,'A. G. Wiley '),(45,'B. Knight '),(46,'S. G. Bennett'),(47,'U. D. Rennie'),(48,'M. L Dean'),(49,'P. A. Durkin '),(50,'G. P. Barber '),(51,'M. A. Riley '),(52,'G. Poll '),(53,'C. R. Wilkes'),(54,'B. Knight'),(55,'A. P. D\'Urso'),(56,'A. G. Wiley'),(57,'D. Pugh'),(58,'P.A. Durkin'),(59,'A.G. Wiley'),(60,'M. A. Riley'),(61,'M. R. Halsey'),(62,'S. W. Dunn'),(63,'E. K. Wolstenholme'),(64,'P. Jones'),(65,'D. R. Elleray'),(66,'M. L. Dean'),(67,'J.T. Winter'),(68,'M. D. Messias'),(69,'P. Dowd'),(70,'C. J. Foy'),(71,'Wiley, A. G.'),(72,'Elleray, D. R.'),(73,'Winter, J. T.'),(74,'Wolstenholme, E. K.'),(75,'Dunn, S. W.'),(76,'Knight, B.'),(77,'Riley, M. A.'),(78,'Rennie, U. D.'),(79,'Durkin, P. A.'),(80,'Barber, G. P.'),(81,'D\'Urso, A. P.'),(82,'Wilkes, C. R.'),(83,'Bennett, S. G.'),(84,'Barry, N. S.'),(85,'Halsey, M. R.'),(86,'Jones, P.'),(87,'Poll, G.'),(88,'Pugh, D.'),(89,'Styles, R.'),(90,'Gallagher, D. J.'),(91,'Dean, M. L'),(92,'Messias, M. D.'),(93,'Styles, R'),(94,'Durkin, P.'),(95,'Foy, C. J.'),(96,'Dowd, P.'),(97,'Yates, N'),(98,'D Elleray'),(99,'G Barber'),(100,'N Barry'),(101,'A Wiley'),(102,'G Poll'),(103,'S Bennett'),(104,'B Knight'),(105,'M Riley'),(106,'A D\'Urso'),(107,'P Durkin'),(108,'D Gallagher'),(109,'M Messias'),(110,'J Winter'),(111,'U Rennie'),(112,'M Dean'),(113,'R Styles'),(114,'C Wilkes'),(115,'S Dunn'),(116,'D Pugh'),(117,'E Wolstenholme'),(118,'M Halsey'),(119,'C Foy'),(120,'P Dowd'),(121,'R Martin'),(122,'H Webb'),(123,'P Walton'),(124,'M Clattenburg'),(125,'M Atkinson'),(126,'P Crossley'),(127,'A Marriner'),(128,'R Beeby'),(129,'I Williamson'),(130,'L Mason'),(131,'K Stroud'),(132,'S Tanner'),(133,'L Probert'),(134,'D Gallagh'),(135,'D Gallaghe'),(136,'S Attwell'),(137,'M Jones'),(138,'K Friend'),(139,'St Bennett'),(140,'Mn Atkinson'),(141,'A Taylor'),(142,'M Oliver'),(143,'N Swarbrick'),(144,'J Moss'),(145,'R East'),(146,'C Pawson'),(147,'R Madley'),(148,'P Tierney'),(149,'G Scott'),(150,'S Hooper'),(151,'C Kavanagh'),(152,'D Coote'),(153,'A Madley'),(154,'O Langford'),(155,'P Bankes'),(156,'T Robinson'),(157,'R Jones'),(158,'S Scott'),(159,'D England'),(160,'A Moss'),(161,'J Gillett'),(162,'M Salisbury'),(163,'J Brooks'),(164,'T Harrington'),(165,'T Bramall'),(166,'D Bond'),(167,'J Smith'),(168,'S Barrott'),(169,'C Salisbury'),(170,'R Welch'),(171,'S Allison'),(172,'L Smith'),(173,'S Singh');
/*!40000 ALTER TABLE `dimreferee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-01 22:01:32
