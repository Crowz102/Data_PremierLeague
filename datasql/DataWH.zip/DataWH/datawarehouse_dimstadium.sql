-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: datawarehouse
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dimstadium`
--

DROP TABLE IF EXISTS `dimstadium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dimstadium` (
  `StadiumiD` int NOT NULL,
  `StadiumName` varchar(255) NOT NULL,
  `CityID` int DEFAULT NULL,
  PRIMARY KEY (`StadiumiD`),
  KEY `CityID` (`CityID`),
  CONSTRAINT `dimstadium_ibfk_1` FOREIGN KEY (`CityID`) REFERENCES `dimcity` (`CityID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dimstadium`
--

LOCK TABLES `dimstadium` WRITE;
/*!40000 ALTER TABLE `dimstadium` DISABLE KEYS */;
INSERT INTO `dimstadium` VALUES (1,'Villa Park',1),(2,'Dean Court',2),(3,'American Express',3),(4,'Falmer',3),(5,'Turf Moor',4),(6,'Cardiff City',5),(7,'Kirklees',6),(8,'Elland Road',7),(9,'King Power',8),(10,'Anfield',9),(11,'Goodison Park',9),(12,'Brentford Community',10),(13,'Craven Cottage',10),(14,'Emirates',10),(15,'London',10),(16,'Selhurst Park',10),(17,'Stamford Bridge',10),(18,'Tottenham Hotspur',10),(19,'Kenilworth Road',11),(20,'Etihad',12),(21,'Old Trafford',12),(22,'St James\' Park',13),(23,'Carrow Road',14),(24,'Bramall Lane',15),(25,'St Mary\'s',16),(26,'Vicarage Road',17),(27,'City Ground',18),(28,'The Hawthorns',19),(29,'Molineux',20);
/*!40000 ALTER TABLE `dimstadium` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-01 22:01:33
